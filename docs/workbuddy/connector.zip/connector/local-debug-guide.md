# CLI 连接器本地调试指南

本文档适用于外部 CLI 开发人员在 WorkBuddy **正式版**（当前 4.22.12）上测试自己的 CLI 连接器。

## 原理

WorkBuddy 启动时会从远程 URL 下载 connector marketplace（一个 zip 包），解压到本地缓存目录。通过覆盖 marketplace URL 为一个不可达地址，可以阻止自动更新，然后手动在本地缓存目录中添加自己的连接器。

## 关键路径

| 项目 | 路径 |
|------|------|
| 配置目录 | `~/.workbuddy/` |
| Marketplace URL 覆盖 | `~/.workbuddy/connectors/connector-marketplace.json` |
| Marketplace 缓存目录 | `~/.workbuddy/connectors-marketplace/` |
| 连接器索引 | `~/.workbuddy/connectors-marketplace/connectors.json` |
| 各连接器目录 | `~/.workbuddy/connectors-marketplace/connectors/<connector-id>/` |

## 步骤

### 1. 阻断自动更新

创建 `~/.workbuddy/connectors/connector-marketplace.json`：

```json
{
  "connectorMarketplaceUrl": "http://127.0.0.1:1/unreachable"
}
```

这会让 WorkBuddy 尝试从一个不可达的地址下载，失败后沿用本地已有缓存。

> 注意：如果本地还没有缓存（全新安装），需要先正常启动一次 WorkBuddy 让它下载初始 marketplace，然后再加这个文件。

### 2. 添加连接器目录

在 `~/.workbuddy/connectors-marketplace/connectors/` 下创建你的连接器目录：

```bash
mkdir -p ~/.workbuddy/connectors-marketplace/connectors/my-cli-tool
```

### 3. 创建连接器配置

```
my-cli-tool/
├── cli.json              # CLI 配置（必须）
└── skills/
    └── SKILL.md          # Agent 使用说明（可选）
```

**cli.json 最小示例**：

```json
{
    "init": {
        "darwin": "npm install -g my-cli-tool",
        "linux": "npm install -g my-cli-tool",
        "win32": "npm install -g my-cli-tool"
    },
    "auth": {
        "darwin": "my-cli auth login",
        "linux": "my-cli auth login",
        "win32": "my-cli.cmd auth login"
    },
    "status": {
        "darwin": "my-cli auth status",
        "linux": "my-cli auth status",
        "win32": "my-cli.cmd auth status"
    },
    "authWaitForExit": true,
    "authUrlDomain": "example.com"
}
```

### 4. 注册到 connectors.json

编辑 `~/.workbuddy/connectors-marketplace/connectors.json`，在 `connectors` 数组中追加你的条目：

```json
{
    "id": "my-cli-tool",
    "name": "My CLI Tool",
    "name_en": "My CLI Tool",
    "description_zh": "我的 CLI 工具描述",
    "description_en": "My CLI tool description",
    "source": "my-cli-tool",
    "type": "cli"
}
```

- `source` 字段对应 `connectors/` 下的目录名
- `type` 字段指定连接器类型（`cli` / `mcp` / `skill-only`）
- 版本约束等元信息也在此声明（如 `"minWorkbuddyVersion": "4.23.0"`）

### 5. 重启 WorkBuddy

关闭并重新打开 WorkBuddy，在连接器面板中应该能看到你的连接器。

## cli.json 字段说明

### 基本字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `init` | 平台命令对象 | 是 | 安装 CLI 工具的命令 |
| `auth` | 平台命令对象 | 否 | 认证/登录命令 |
| `unAuth` | 平台命令对象 | 否 | 登出/取消认证命令 |
| `status` | 平台命令对象 | 否 | 检查登录状态的命令 |
| `statusMatch` | string | 否 | 正则表达式，匹配 status 命令的 stdout+stderr 文本。匹配成功视为"已连接" |
| `authWaitForExit` | boolean | 否 | 是否等待 auth 命令退出后才判定连接结果（默认 false） |
| `authUrlDomain` | string | 否 | 从 auth 命令输出中提取 URL 时的域名过滤（只打开包含该域名的 URL） |
| `authSuppressBrowser` | boolean | 否 | 设为 true 时 WorkBuddy 不自动打开浏览器（CLI 自己处理） |
| `runtime` | object | 否 | 运行时声明（如 `{ "type": "node", "version": ">=18" }`） |

### 平台命令对象格式

```json
{
    "darwin": "命令（macOS）",
    "linux": "命令（Linux）",
    "win32": "命令（Windows）"
}
```

### statusMatch 说明

`statusMatch` 的值会被当作 JavaScript 正则表达式（`new RegExp(value)`）来匹配。当 status 命令 exit 0 且输出匹配该正则时，判定为已连接。

示例：

```json
{
    "status": { "darwin": "my-cli auth status" },
    "statusMatch": "logged\\s*in|authenticated"
}
```

如果不提供 `statusMatch`，仅以 exit code === 0 判断是否已连接。

## 调试技巧

### 查看日志

连接器相关日志位于 WorkBuddy 日志目录。搜索关键词：

- `[ConnectorService]` — 连接/断开/状态检查
- `[CliExecutor]` — CLI 命令执行详情（含 stdout/stderr）

### authUrlDomain

CLI 的 auth 命令如果需要打开浏览器，WorkBuddy 会监听 stdout/stderr 中包含 `authUrlDomain` 的 URL 并自动打开。确保你的 CLI 在非 TTY 模式下输出完整授权 URL。

### authSuppressBrowser

如果你的 CLI 自己管理浏览器打开（不需要 WorkBuddy 帮忙打开 URL），设置：

```json
{
    "authSuppressBrowser": true
}
```

## 恢复正常

调试完毕后删除覆盖文件即可恢复自动更新：

```bash
rm ~/.workbuddy/connectors/connector-marketplace.json
```

下次启动 WorkBuddy 会从远程重新下载最新 marketplace，覆盖你的本地改动。

## 注意事项

1. `connectors.json` 中的 `source` 必须与 `connectors/` 下的目录名完全一致
2. 正式版的 configDir 是 `~/.workbuddy/`，开发版是 `~/.workbuddy-oss-dev/`
3. 如果连接器不出现在面板中，检查 `connectors.json` 条目中的 `minWorkbuddyVersion` 是否高于当前版本
4. Marketplace 缓存目录的更改在 WorkBuddy 重启后生效
